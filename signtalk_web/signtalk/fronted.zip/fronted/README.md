## 前端fronted

视频通话时需，一方先启动服务器 npm run serve

运行前端 npm run dev

## 后端

运行python manage.py runserver